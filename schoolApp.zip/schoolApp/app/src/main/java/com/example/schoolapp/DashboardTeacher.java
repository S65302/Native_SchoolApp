package com.example.schoolapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class DashboardTeacher extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle toggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_teacher);

        // Initialize DrawerLayout and Toggle
        drawerLayout = findViewById(R.id.drawer_layout);
        toggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // Initialize NavigationView
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.nav_dashboard:
                        drawerLayout.closeDrawer(GravityCompat.END);
                        Toast.makeText(DashboardTeacher.this, "Dashboard Selected", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_add_announcement:
                        Intent addAnnouncementIntent = new Intent(DashboardTeacher.this, AddAnnouncementActivity.class);
                        startActivity(addAnnouncementIntent);
                        break;
                    case R.id.nav_announcement_list:
                        Intent announcementListIntent = new Intent(DashboardTeacher.this, AnnouncementListActivity.class);
                        startActivity(announcementListIntent);
                        break;
                    case R.id.nav_edit_results:
                        Intent editResultsIntent = new Intent(DashboardTeacher.this, EditResultsActivity.class);
                        startActivity(editResultsIntent);
                        break;
                    case R.id.nav_result_hub:
                        Intent resultHubIntent = new Intent(DashboardTeacher.this, ResultHubActivity.class);
                        startActivity(resultHubIntent);
                        break;
                    case R.id.nav_new_registration:
                        Intent newRegistrationIntent = new Intent(DashboardTeacher.this, NewStudentRegistrationActivity.class);
                        startActivity(newRegistrationIntent);
                        break;
                    case R.id.nav_logout:
                        finishAffinity(); // Close all activities
                        break;
                }
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });

        // Populate main content with school info
        populateContent();
    }

    private void populateContent() {
        // Add your content population logic here
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (toggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}

