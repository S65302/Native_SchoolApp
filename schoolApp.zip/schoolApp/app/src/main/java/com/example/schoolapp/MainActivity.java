package com.example.schoolapp;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set the main content view (activity_main.xml layout)
        setContentView(R.layout.activity_main);

        // Navigate to Screen1 after a brief delay (optional)
        // If you want to show the MainActivity for a brief period before transitioning to Screen1, you can add a delay.

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    // Optional: Add a delay (for example, to show a splash screen or some introductory content)
                    Thread.sleep(2000); // Sleep for 2 seconds
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                // Start Screen1 after the delay
                Intent intent = new Intent(MainActivity.this, Screen1.class);
                startActivity(intent);
                finish(); // Finish MainActivity so it doesn't remain in the back stack
            }
        }).start();
    }
}
